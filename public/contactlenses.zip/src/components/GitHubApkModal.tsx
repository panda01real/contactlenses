import React, { useState } from 'react';
import {
  X,
  Github,
  Download,
  Terminal,
  ExternalLink,
  Copy,
  Check,
  Smartphone,
  Cpu,
  Sparkles,
} from 'lucide-react';

interface GitHubApkModalProps {
  onClose: () => void;
}

export const GitHubApkModal: React.FC<GitHubApkModalProps> = ({ onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const gitCommands = [
    'git remote add origin https://github.com/marcospereyra07/ocutrack.git',
    'git branch -M main',
    'git push -u origin main',
  ];

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const appUrl = 'https://ais-pre-ijhmaa6wstn2q5pjq6uuxi-482098825277.us-east1.run.app';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-5 my-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Publicar en GitHub & Generar .APK
              </h3>
              <p className="text-xs text-slate-500">Pasos para tu Samsung S23 FE y repositorio</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section 1: Cómo obtener el APK */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400 flex items-center gap-1.5">
            <Smartphone className="w-4 h-4" />
            <span>Opciones para tener el archivo .APK:</span>
          </h4>

          {/* Option A: GitHub Actions Automatic Build */}
          <div className="p-3.5 rounded-2xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-900/50 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-sky-950 dark:text-sky-200 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-sky-500" />
                1. Compilación automática en GitHub (CI/CD)
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-200 dark:bg-sky-800 text-sky-800 dark:text-sky-200">
                Automático
              </span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300">
              El repositorio ya cuenta con el flujo <strong>`.github/workflows/build-apk.yml`</strong>. Al hacer <code>git push</code> a tu GitHub, GitHub compilará el archivo <code>app-debug.apk</code> en la pestaña <strong>Actions</strong> y lo dejará listo para descargar.
            </p>
          </div>

          {/* Option B: PWABuilder (Instant Cloud APK) */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-emerald-950 dark:text-emerald-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                2. Generar APK en la nube (PWABuilder)
              </span>
              <a
                href={`https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`}
                target="_blank"
                rel="noreferrer"
                className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700"
              >
                <span>Abrir web</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300">
              Genera tu APK firmado para Android en 30 segundos pegando la URL de tu app en PWABuilder sin necesidad de instalar Android Studio en tu PC.
            </p>
          </div>
        </div>

        {/* Section 2: Comandos para subir a GitHub */}
        <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-slate-500" />
            <span>Comandos para conectar y subir a tu GitHub:</span>
          </h4>

          <div className="p-3 rounded-2xl bg-slate-900 text-slate-200 font-mono text-xs space-y-2">
            <div className="text-[11px] text-slate-400">
              # Primero crea el repo "ocutrack" en github.com/new, luego ejecuta:
            </div>
            {gitCommands.map((cmd, idx) => (
              <div key={idx} className="flex items-center justify-between gap-2 p-1 rounded-md hover:bg-slate-800">
                <span className="break-all">{cmd}</span>
                <button
                  type="button"
                  onClick={() => handleCopy(cmd, idx)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                  title="Copiar comando"
                >
                  {copiedIndex === idx ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => handleCopy(gitCommands.join(' && '), 99)}
            className="w-full py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 transition"
          >
            {copiedIndex === 99 ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>¡Todos los comandos copiados!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-sky-500" />
                <span>Copiar todos los comandos juntos</span>
              </>
            )}
          </button>
        </div>

        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-bold text-xs"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
