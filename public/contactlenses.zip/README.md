# 👁️ OcuTrack - Contador de Lentes de Contacto (Android / Samsung Galaxy S23 FE)

Aplicación moderna para Android y la web diseñada específicamente para llevar el registro diario del uso de lentes de contacto, calcular los días de vida restante de cada par y recibir notificaciones para cambiarlos a tiempo.

---

## 🚀 Cómo subir este proyecto a tu GitHub

Sigue estos 3 sencillos pasos en tu terminal para publicar este código en tu cuenta de GitHub (`marcospereyra07`):

### 1. Crea el repositorio en GitHub
Ve a [github.com/new](https://github.com/new) y crea un repositorio público llamado **`ocutrack`** (sin marcar "Add a README", ya que este proyecto ya lo incluye).

### 2. Conecta y sube el código desde tu terminal:
```bash
# 1. Agrega tu repositorio remoto de GitHub:
git remote add origin https://github.com/marcospereyra07/ocutrack.git

# 2. Asegúrate de estar en la rama main:
git branch -M main

# 3. Sube todos los archivos:
git push -u origin main
```

---

## 📱 Cómo obtener el archivo `.apk` para tu Samsung S23 FE

Tienes **3 opciones directas** para tener la app en tu teléfono:

### Opción 1: Compilación Automática en GitHub Actions (¡Recomendada!)
El repositorio incluye un flujo de trabajo automatizado en `.github/workflows/build-apk.yml`.
1. Una vez que hagas `git push` a tu repositorio de GitHub, ve a la pestaña **Actions** en tu GitHub.
2. Verás el flujo de trabajo **"Build Android APK"** ejecutándose automáticamente.
3. Al terminar (tarda ~2 minutos), haz clic en la ejecución y en la sección **Artifacts** descarga el archivo:
   👉 **`OcuTrack-Android-APK`** (dentro vendrá el archivo `app-debug.apk`).
4. Pásalo a tu Samsung S23 FE por WhatsApp, Telegram o Drive e instálalo directamente.

### Opción 2: Generar APK en la nube con PWABuilder (En 30 segundos, sin instalar nada)
1. Entra a [PWABuilder.com](https://www.pwabuilder.com).
2. Pega la URL de tu aplicación publicada:
   `https://ais-pre-ijhmaa6wstn2q5pjq6uuxi-482098825277.us-east1.run.app`
3. Haz clic en **"Start"** y luego en **"Package for Android"**.
4. ¡Descarga tu archivo `.apk` o `.aab` listo para instalar!

### Opción 3: Instalación Directa como PWA en tu Samsung S23 FE (Sin descargar APK)
La aplicación cuenta con soporte completo PWA (Progressive Web App):
1. Abre el enlace en **Google Chrome** o **Samsung Internet** en tu Samsung S23 FE:
   `https://ais-pre-ijhmaa6wstn2q5pjq6uuxi-482098825277.us-east1.run.app`
2. Toca el botón **"Instalar en Android"** en la barra superior o en el menú del navegador (⋮) > **"Instalar aplicación"** / **"Añadir a pantalla de inicio"**.
3. La aplicación se instalará con su propio ícono en el cajón de aplicaciones de Samsung One UI, funciona sin conexión a internet y tiene acceso a las notificaciones y vibración háptica.

### Opción 4: Compilar localmente con Android Studio
Si tienes Android Studio instalado en tu computadora:
```bash
# Instalar dependencias
npm install

# Compilar proyecto web
npm run build

# Sincronizar y abrir en Android Studio
npx cap open android
```
En Android Studio, ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---

## ✨ Características de OcuTrack

- **Registro Diario en 1 Toque**: Marca rápidamente si te pusiste o no los lentes hoy con retroalimentación sonora de gota de agua y vibración háptica.
- **Días Restantes y Modos de Cálculo**:
  - *Días de uso real*: Descuenta solo los días que efectivamente te los pusiste.
  - *Días calendario corridos*: Descuenta 1 día cada 24 horas desde que abriste el blíster.
- **Simulador de Widget One UI 6**: Vista previa interactiva de widgets 4x2 y 2x2 para Android.
- **Notificaciones Nativas**:
  - Recordatorio diario matutino para no olvidar registrar el uso.
  - Alerta de cambio de par (3 días antes, 1 día antes y par vencido).
  - Recordatorio nocturno para retirar y desinfectar los lentes antes de dormir.
- **Calendario Mensual**: Historial interactivo con estados de uso por día.
- **Parámetros Oftálmicos**: Registro de graduación (OD / OS, curva base, diámetro y marca de solución).
- **Control de Higiene**: Contador para reemplazo del estuche porta-lentes cada 90 días.
- **Copia de Seguridad**: Exportación e importación de datos en formato JSON.

---

## 🛠️ Tecnologías Utilizadas

- **React 19** + **TypeScript**
- **Vite** + **Tailwind CSS v4**
- **Capacitor Android** (para empaquetado nativo APK)
- **Vite PWA** (Service Worker, Web App Manifest y Offline caching)
- **GitHub Actions** (CI/CD para compilación de APK en la nube)
- **Web Audio API & Vibration API** (Hápticos estilo Samsung One UI)
